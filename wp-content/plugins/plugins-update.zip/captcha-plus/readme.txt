=== Captcha Plus by BestWebSoft ===
Contributors: bestwebsoft
Donate link: http://bestwebsoft.com/donate/
Tags: add, anti, anti-spam, anti-spam security, antispam, antispam security, antispambot, arithmetic actions, blacklist, block spam, bot, bots, best captcha, best wordpress captcha, captcha, capcha, captha, catcha, captcha bank, captcha numbers, captcha plugin, captcha protection, captcha words, contact form with captcha, comment captcha, comment, comments, cpatcha, form, forms, form captcha, forgot password captcha, free, login, lost password, label, login captcha, match captcha, math actions, multiply, plugin, protect, protection, popular captcha, protection shield, register, registration, registration spam, register captcha, rest password captcha, registration captcha security, spam, secure, security, signup, signup spam, spam blocker, spam comments, spam filter, spambot, shield, simple captcha, spam control, spam protection, substract, text captcha, user registration spam, web form protection, wordpress captcha, wordpress protection, wordpress security loss password captcha, register captcha, wp captcha, wp plugin, wp plugins
Requires at least: 3.8
Tested up to: 4.4.2
Stable tag: 1.1.3
License: Proprietary
License URI: http://bestwebsoft.com/end-user-license-agreement/

This plugin allows you to implement super security captcha form into web forms. 

== Description ==

The Captcha plugin adds a captcha form into web pages. This captcha can be used for login, registration, password recovery, comments forms. It protects your website from spammers by means of math logic, easily understandable by human beings. All you need is to do one of the three basic maths actions - add, subtract and multiply. You will not have to spend your precious time on annoying attempts to understand hard-to-read words, combinations of letters or surreal pictures.
This captcha can be used for login, registration, password recovery, comments forms.

http://www.youtube.com/watch?v=jxrvHaCmQfg

<a href="http://www.youtube.com/watch?v=jsvc8FxxEnk" target="_blank">Captcha Plus by BestWebSoft Video instruction on Installation</a>

<a href="http://bestwebsoft.com/products/captcha/faq/" target="_blank">Captcha Plus by BestWebSoft FAQ</a>

<a href="http://support.bestwebsoft.com" target="_blank">Captcha Plus by BestWebSoft Support</a>

= Features =

* Supports standard WordPress forms: registration form, login form, reset password form and comments form.
* Contact Form by BestWebSoft compatibility.
* Contact Form 7 compatibility (since version 3.4).
* You can use letters, numbers and images in captcha or just one of these three things - either letters, numbers or images.
* The basic math actions are used - add, subtract, multiply.
* Ability to hide Captcha for whitelisted IP.
* Ability to set time limit for Captcha completing.
* Ability to reload Captcha.
* You can add a label to display captcha in the form.
* Ability to load whitelist of Limit Attempts by BestWebSoft plugin to whitelist of Captcha Plus by BestWebSoft.
* Ability to use whitelist of Limit Attempts by BestWebSoft plugin.

If you have a feature, suggestion or idea you'd like to see in the plugin, we'd love to hear about it! <a href="http://support.bestwebsoft.com/hc/en-us/requests/new" target="_blank">Suggest a Feature</a>

= Recommended Plugins =

The author of the Captcha Plus also recommends the following plugins:

* <a href="http://wordpress.org/plugins/limit-attempts/">Limit Attempts</a> - This plugin allows you to limit users' attempts to log in to your website, as well as create and edit black- and whitelists. This way, you will be able to manage access to your website and its content and protect it from spam and unwanted visitors.
* <a href="http://wordpress.org/plugins/updater/">Updater</a> - This plugin updates WordPress core and the plugins to the recent versions. You can also use the auto mode or manual mode for updating and set email notifications.

= Translation =

* Arabic (ar_AR) (thanks to Albayan Design Hani Aladoli)
* Bangla (bn_BD) (thanks to <a href="mailto:mehdi.akram@gmail.com">SM Mehdi Akram</a>, www.shamokaldarpon.com)
* Brazilian Portuguese (pt_BR) (thanks to <a href="mailto:brenojac@gmail.com">Breno Jacinto</a>, www.iconis.org.br)
* Bulgarian (bg_BG) (thanks to <a href="mailto:paharaman@gmail.com">Nick</a>)
* Catalan (ca) (thanks to <a href="mailto:psiete@gmail.com">Psiete</a>)
* Chinese (zh_CN) (thanks to <a href="mailto:newbiesup@gmail.com">Newbiesup</a>, www.wpsites.org)
* Taiwan (zh_TW) (thanks to <a href="mailto:hh3stuff@gmail.com">Henry H</a>)
* Croatian (hr) (thanks to <a href="mailto:daniel@croteh.com">Daniel</a>)
* Czech (cs_CZ) (thanks to <a href="mailto:crysman@seznam.cz">Crysman</a>)
* Danish (da_DK) (thanks to Byrial Ole Jensed)
* Dutch (nl_NL) (thanks to <a href="mailto:byrial@vip.cybercity.dk">Bart Duineveld</a>)
* Estonian (et) (thanks to Ahto Tanner)
* Greek (el) (thanks to Aris, www.paraxeno.net)
* Farsi/Persian (fa_IR) (thanks to <a href="mailto:mostafaasadi73@gmail.com">Mostafa Asadi</a>, www.ma73.ir, <a href="mailto:Morteza.Gholami@Yahoo.Com">Morteza Gholami</a>)
* Finnish (fi) (thanks to Mikko Sederholm)
* French (fr_FR) (thanks to Martel Benjamin, <a href="mailto:lcapronnier@yahoo.com">Capronnier luc</a>)
* German (de_DE) (thanks to Thomas Hartung, <a href="mailto:lothar.schiborr@web.de">Lothar Schiborr</a>)
* Hebrew (he_IL) (thanks to Sagive SEO)
* Hindi (hi_IN) (thanks to <a href="mailto:ash.pr@outshinesolutions.com">Outshine Solutions</a>, www.outshinesolutions.com)
* Hungarian (hu_HU) (thanks to <a href="mailto:solarside09@gmail.com">Peter Aprily</a>)
* Japanese (ja) (thanks to Foken)
* Indonesian (id_ID) (thanks to <a href="mailto:nasroel@al-badar.net">Nasrulhaq Muiz</a>, www.al-badar.net)
* Italian (it_IT) (thanks to <a href="mailto:marco@blackstudio.it">Marco</a>)
* Latvian (lv) (thanks to <a href="mailto:juris.o@gmail.com">Juris O</a>)
* Lithuanian (lt_LT) (thanks to <a href="mailto:arnas.metal@gmail.com">Arnas</a>)
* Norwegian (nb_NO) (thanks to Tore Hjartland)
* Polish (pl_PL) (thanks to Krzysztof Opuchlik)
* Portuguese (pt_PT) (thanks to <a href="mailto:jp.jp@sapo.pt">João Paulo Antunes</a>)
* Romanian (ro_RO) (thanks to Ciprian)
* Russian (ru_RU)
* Serbian (sr_RS) (thanks to Radovan Georgijevic)
* Slovak (sk_SK) (thanks to Branco Radenovich)
* Slovenian (sl_SI) (thanks to <a href="mailto:uros.klopcic@gmail.com">Uroš Klopčič</a>, www.klopcic.net)
* Spain (es_ES) (thanks to Iván García Cubero)
* Swedish (sv_SE) (thanks to Christer Rönningborg, <a href="mailto:blittan@xbmc.org">Blittan</a>)
* Tagalog (tl) (thanks to <a href="mailto:rjalali@languageconnect.net">Roozbeh Jalali</a>, www.languageconnect.net)
* Turkish (tr_TR) (thanks to Can Atasever, www.canatasever.com)
* Ukrainian (uk)
* Vietnamese (vi_VN) (thanks to NDT Solutions)

If you would like to create your own language pack or update the existing one, you can send <a href="http://codex.wordpress.org/Translating_WordPress" target="_blank">the text of PO and MO files</a> for <a href="http://support.bestwebsoft.com" target="_blank">BestWebSoft</a> and we'll add it to the plugin. You can download the latest version of the program for work with PO and MO files <a href="http://www.poedit.net/download.php" target="_blank">Poedit</a>.

= Technical support =

Dear users, our plugins are available for free download. If you have any questions or recommendations regarding the functionality of our plugins (existing options, new options, current issues), please feel free to contact us. Please note that we accept requests in English only. All messages in another languages won't be accepted.

If you notice any bugs in the plugins, you can notify us about it and we'll investigate and fix the issue then. Your request should contain URL of the website, issues description and WordPress admin panel credentials.
Moreover we can customize the plugin according to your requirements. It's a paid service (as a rule it costs $40, but the price can vary depending on the amount of the necessary changes and their complexity). Please note that we could also include this or that feature (developed for you) in the next release and share with the other users then. 
We can fix some things for free for the users who provide translation of our plugin into their native language (this should be a new translation of a certain plugin, you can check available translations on the official plugin page).

== Installation ==

1. Upload the `captcha-plus` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin via the 'Plugins' menu in WordPress.
3. Plugin settings are located in "BWS Plugins" > "Captcha Plus".

<a href="https://docs.google.com/document/d/1DN2yYCvDyK2LqmbWw6xmUNLbb0awOVDZ_dOgIXod-Jw/edit" target="_blank">View a Step-by-step Instruction on Captcha Installation</a>.

http://www.youtube.com/watch?v=jsvc8FxxEnk

== Frequently Asked Questions ==

= I would like to add Captcha Plus to the Contact Form 7. How can I do this? =

1. Make sure you enabled "Contact Form 7" on the Captcha Plus settings page.
2. Go to "Contact Form 7" form where you want to make use of Captcha.
3. For the Contact Form 7 since version 4.2 on the edit form page select the BWS CAPTCHA form-tag, and insert it into your form. For the Contact Form 7 below version 4.2 on the edit form page find a dropdown menu with the form fields, select BWS CAPTCHA and insert it into your form.

= Missing Captcha on the comment form? = 

You might have a theme where comments.php is not coded properly. 

Wordpress version matters. 

(WP2 series) Your theme must have a tag `<?php do_action('comment_form', $post->ID); ?>` inside the file `/wp-content/themes/[your_theme]/comments.php`. 
Most WP2 themes already have it. The best place to put this tag is before the comment textarea, you can move it up if it is below the comment textarea.

(WP3 series) WP3 has a new function comment_form inside of `/wp-includes/comment-template.php`. 
Your theme is probably not up-to-date to call that function from comments.php.
WP3 theme does not need the code line `do_action('comment_form'`... inside of `/wp-content/themes/[your_theme]/comments.php`.
Instead it uses a new function call inside of comments.php: `<?php comment_form(); ?>`
If you have WP3 and captcha is still missing, make sure your theme has `<?php comment_form(); ?>`
inside of `/wp-content/themes/[your_theme]/comments.php` (please check the Twenty Ten theme's comments.php for proper example)

= Can I move the Captcha block in the comment form? =

It depends on the comments form. If the hook call by means of which captcha works (after_comment_field or something like this) is present in the file comments.php, you can change captcha positioning by moving this hook call.

Please find the file 'comments.php' in the theme and change position of the line `do_action( 'comment_form_after_fields' );` or any similar line - place it under the Submit button.
In case there is no such hook in the comments file of your theme, then, unfortunately, this option is not available.

= I would like to add Captcha Plus to the custom form on my website. How can I do this? =

1. Install the Captcha Plus plugin and activate it.
2. Open the file with the form (where you would like to add captcha to).
3. Find a place to insert the code for the captcha output.
4. Insert the necessary lines: 

`if( function_exists( 'cptchpls_display_captcha_custom' ) ) { echo "<input type='hidden' name='cntctfrm_contact_action' value='true' />"; echo cptchpls_display_captcha_custom(); }`

If the form is HTML you should insert the line with the PHP tags:

`<?php if( function_exists( 'cptch_display_captcha_custom' ) ) { echo "<input type='hidden' name='cntctfrm_contact_action' value='true' />"; echo cptch_display_captcha_custom(); } ?>`

5. Then you should add the lines to the function of the entered data checking  

`if( function_exists( 'cptchpls_check_custom_form' ) && cptchpls_check_custom_form() !== true ) echo "Please complete the CAPTCHA.";`

or

`<?php if( function_exists( 'cptchpls_check_custom_form' ) && cptchpls_check_custom_form() !== true ) echo "Please complete the CAPTCHA."; ?>`

You could add this line to the variable and display this variable in the required place instead of `echo "Please complete the CAPTCHA."`. If there is a variable (responsible for the errors output) in the check function, this phrase can be added to this variable. If the function returns 'true', it means that you have entered captcha properly. In all other cases the function will return 'false'.

= I have some problems with the plugin's work. What Information should I provide to receive proper support? =

Please make sure that the problem hasn't been discussed yet on our forum (<a href="http://support.bestwebsoft.com" target="_blank">http://support.bestwebsoft.com</a>). If no, please provide the following data along with your problem's description:

1. the link to the page where the problem occurs
2. the name of the plugin and its version. If you are using a pro version - your order number.
3. the version of your WordPress installation
4. copy and paste into the message your system status report. Please read more here: <a href="https://docs.google.com/document/d/1Wi2X8RdRGXk9kMszQy1xItJrpN0ncXgioH935MaBKtc/edit" target="_blank">Instruction on System Status</a>

== Screenshots ==

1. Captcha Plus Basic Settings page.
2. Captcha Plus Advanced Settings page.
3. Captcha Plus Whitelist.
4. Login form with Captcha Plus.
5. Registration form with Captcha Plus.
6. Lost password form with Captcha Plus.
7. Comments form with Captcha Plus.
8. Contact form with Captcha Plus.

== Changelog ==

= V1.1.3 - 28.03.2016 =
* Bugfix : Lower-case equivalents for all numbers have been changed.
* New : Ability to add custom styles.

= V1.1.2 - 01.02.2016 =
* Bugfix : Captcha's work in the multisite registration form has been fixed.
* Bugfix : SQL injection vulnerability has been fixed (thanks to www.ncsc.nl).
* Bugfix : The bug of displaying captha error when adding a new user in the multisite has been fixed.
* Update : The French language file has been updated.

= V1.1.1 - 17.12.2015 =
* Bugfix : Bug with the definition of type of images has been fixed.

= V1.1.0 - 10.12.2015 =
* New : Ability to use images in Captcha.
* New : Ability to reload Captcha.
* New : Ability to load list of IP from whitelist of Limit Attempts by BestWebSoft plugin to Captcha whitelist.
* New : Ability to use whitelist of Limit Attempts by BestWebSoft plugin.
* New : Ability to set time limit, after which the Captcha can not be passed.
* Bugfix : Bug with Captcha reloading when forms data handled via ajax was fixed.
* Bugfix : XSS vulnerability with displaying search results for Captcha whitelist was fixed (thanks to <a href="mailto:colette@wordfence.com">Colette Chamberland</a>).
* Bugfix : XSS vulnerability with user authentication was fixed (thanks to <a href="mailto:colette@wordfence.com">Colette Chamberland</a>).
* Update : Structure of plugin`s settings page was updated.
* Update : The French and Hungarian language files were updated.

= V1.0.9 - 24.09.2015 =
* New : The whitelist functionality was expanded: Ability to add current IP to the whitelist.
* New : The whitelist functionality was expanded: If the IP is in the whitelist, then the indicated message will be displayed instead of the captcha.
* Update : We updated all functionality for wordpress 4.3.1.
* Update : The French language file is updated.
* Bugfix : We fixed SQL injection vulnerability.

= V1.0.8 - 18.08.2015 =
* New : Ability to hide Captcha for whitelisted IP.
* Update : We updated all functionality for wordpress 4.2.4.
* Update : We updated structure of plugin settings page.
* Bugfix : We fixed bug with displaying Captcha for rtl-oriented languages.

= V1.0.7 - 02.07.2015 =
* New : Ability to restore settings to defaults.

= V1.0.6 - 10.06.2015 =
* Update : We updated all functionality for Contact Form 7 v4.2.

= V1.0.5 - 02.06.2015 =
* Bugfix : We fixed error of a visual display of the settings page.
* Bugfix : We fixed the Required symbol that has not been displayed on login, registration and password recovery form.

= V1.0.4 - 20.03.2015 =
* Update : The Croatian, French and Farsi languages file are updated.
* Update: Error display with the comments form was changed.
* Update : We updated all functionality for Contact Form 7 v4.1.

= V1.0.3 - 18.02.2015 =
* NEW: We added the ability to change error messages.

= V1.0.2 - 23.12.2014 =
* Update : The language files are updated.

= V1.0.1 - 19.12.2014 =
* Update : The plugin was updated due to CodeCanyon request.

= V1.0.0 - 24.11.2014 =
* Release date of Captcha Plus.

== Upgrade Notice ==

= V1.1.3 =
Lower-case equivalents for all numbers have been changed. Ability to add custom styles.

= V1.1.2 =
Captcha's work in the multisite registration form was fixed. SQL injection vulnerability was fixed. The bug of displaying captha error when adding a new user in the multisite is fixed. The French language file is updated.

= V1.1.1 =
Bug with the definition of type of images has been fixed.

= V1.1.0 =
Ability to use images in Captcha. Ability to reload Captcha.  Ability to load list of IP from whitelist of Limit Attempts by BestWebSoft plugin to Captcha whitelist. Ability to use whitelist of Limit Attempts by BestWebSoft plugin. Ability to set time limit, after which the Captcha can not be passed. Bug with Captcha reloading when forms data handled via ajax was fixed. XSS vulnerability with displaying search results for Captcha whitelist was fixed (thanks to <a href="mailto:colette@wordfence.com">Colette Chamberland</a>). XSS vulnerability with user authentication was fixed (thanks to <a href="mailto:colette@wordfence.com">Colette Chamberland</a>). Structure of plugin`s settings page was updated. The French and Hungarian language files were updated.

= V1.0.9 =
The whitelist functionality was expanded: Ability to add current IP to the whitelist. The whitelist functionality was expanded: If the IP is in the whitelist, then the indicated message will be displayed instead of the captcha. We updated all functionality for wordpress 4.3.1. The French language file is updated. We fixed SQL injection vulnerability.

= V1.0.8 =
Ability to hide Captcha for whitelisted IP. We updated all functionality for wordpress 4.2.4. We updated structure of plugin settings page. We fixed bug with displaying Captcha for rtl-oriented languages.

= V1.0.7 =
Ability to restore settings to defaults.

= V1.0.6 =
Contact Form 7 v4.2. compatibility update.

= V1.0.5 =
We fixed error of a visual display of the settings page. We fixed the Required symbol that has not been displayed on login, registration and password recovery form.

= V1.0.4 =
The Croatian, French and Farsi languages file are updated. Error display with the comments form was changed. We updated all functionality for Contact Form 7 v4.1.

= V1.0.3 =
We added the ability to change error messages.

= V1.0.2 =
The language files are updated.

= V1.0.1 =
The plugin was updated due to CodeCanyon request.

= V1.0.0 =
Release date of Captcha Plus.
