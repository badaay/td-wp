<?php
/**
 * Template Name: Swiper s3 Page
 */
?>

<div class="swiper-slide">
	<div class='ScrollPage SwiperSlide-2345' style='background-image: url(<?= $data['background']['sizes']['1920']; ?>);'>
		<div class='align'>
			<div class='text-cell'>
				<?= $data['text']; ?>
			</div>
		</div>
	</div>
</div>